import csv
import datetime
""" GUI denemeleri yapıldı ama başarısız olundu :(
import tkinter as tk

pencere=tk.Tk()
pencere.geometry("800x600+250+70")
etiket=tk.Label(text="MENÜ",bg="#ffc0cb",font="Times 18")
etiket.place(x=130,y=60)
menu=tk.Label(text="Pizza Tabanları"
                   "1: KLASİK (100 Lira)\n"
                   "2: MARGERİTA (115 Lira\n"
                   "3: TÜRKPİZZA (130 Lira)\n"
                   "4: SADEPİZZA (93 Lira)\n"
                "Malzemeler\n"
                   "11: Zeytin (7 Lira)\n"
                   "12: Mantar (5.5 Lira)\n"
                   "13: KeçiPeyniri (9.25 Lira)\n"
                   "14: Et (14.90 Lira)\n"
                   "15: Soğan (5.25 Lira)\n"
                   "16: Mısır (3.95 Lira)\n "
                   "* Teşekkür Ederiz:)\n",

                   bg="#da70d6",font="15")
menu.place(x=50,y=120)
etiket1=tk.Label(text="SİPARİŞ",bg="#ffc0cb",font="Times 18")
etiket1.place(x=450,y=60)
name =tk.Label( text = "pizza tercihiniz:").place(x = 400,y = 100)
e1 = tk.Entry(pencere).place(x = 510, y = 100)"""

with open("PizzaMenu.txt", "w") as menu:
    menu.write("""* İstediğiniz bir pizza tabanı seçiniz:
1: KLASİK (100 Lira)
2: MARGERİTA (115 Lira)
3: TÜRKPİZZA (130 Lira)
4: SADEPİZZA (93 Lira)
* ve istediğiniz malzemeleri seçiniz:
11: Zeytin (7 Lira)
12: Mantar (5.5 Lira)
13: KeçiPeyniri (9.25 Lira)
14: Et (14.90 Lira)
15: Soğan (5.25 Lira)
16: Mısır (3.95 Lira) 
* Teşekkür Ederiz:) \n""")



with open("PizzaMenu.txt") as menu:
    menu_dict = {}
    for line in menu:
        if "*" in line:
            continue
        (key, val) = line.split(": ")
        val = val[:-1]
        menu_dict[int(key)] = val

class Pizza:
    def get_description(self):
        return self.__class__.__name__

    def get_cost(self):
        return self.__class__.cost


class Margerita(Pizza):
    cost = 115

    def __init__(self):
        self.description = "domates, mozarella, fesleğen, zeytinyağı"


class Klasik(Pizza):
    cost = 100

    def __init__(self):
        self.description = "domates, peynir ve genellikle çeşitli diğer malzemelerle (hamsi, mantar, soğan, zeytin, ananas, et vb.)"


class TürkPizza(Pizza):
    cost = 130

    def __init__(self):
        self.description = "domates sosu, jambon dilimleri, ananas parçaları ve mozzarella peyniri"


class SadePizza(Pizza):
    cost = 93

    def __init__(self):
        self.description = "domates,peynir,zeytin"


class Decorator(Pizza):
    def __init__(self, topping):
        self.component = topping

    def get_cost(self):
        return self.component.get_cost() + \
          Pizza.get_cost(self)

    def get_description(self):
        return self.component.get_description() + \
          ' ' + Pizza.get_description(self)


class Zeytin(Decorator):
    cost = 7

    def __init__(self, topping):
        Decorator.__init__(self, topping)


class Mantar(Decorator):
    cost = 5.5

    def __init__(self, topping):
        Decorator.__init__(self, topping)


class KeçiPeyniri(Decorator):
    cost = 9.25

    def __init__(self, topping):
        Decorator.__init__(self, topping)


class Et(Decorator):
    cost = 14.90

    def __init__(self, topping):
        Decorator.__init__(self, topping)


class Soğan(Decorator):
    cost = 5.25

    def __init__(self, topping):
        Decorator.__init__(self, topping)


class Mısır(Decorator):
    cost = 3.95

    def __init__(self, topping):
        Decorator.__init__(self, topping)



def main():
    with open("PizzaMenu.txt") as cust_menu:
        for l in cust_menu:
            print(l, end="")

    class_dict = {1: Klasik, 2: Margerita, 3: TürkPizza, 4: SadePizza, 11: Zeytin, 12: Mantar, 13: KeçiPeyniri, 14: Et, 15: Soğan, 16: Mısır}

    code = input("Pizza tabanı için 1'den 4'e kadar bir sayı seçiniz: ")
    while code not in ["1", "2", "3", "4"]:
        code = input("Pizza tabanı için 1'den 4'e kadar bir sayı seçiniz: ")

    order = class_dict[int(code)]()

    while code != "*":
        code = input("İsetdiğiniz malzemeleri 11'den 16'ya kadar istediğiniz rakamları girerek belirtiniz.(Malzemeleri yeterli bulduğunuzda * seçeneğini girin.):")
        if code in ["11", "12", "13", "14", "15", "16"]:
            order = class_dict[int(code)](order)

    print("\n"+order.get_description().strip() +
          ": $" + str(order.get_cost()))
    name = input("Ödeme adımına geçmeden önce isim ve soyisiminizi girer misiniz?: ")
    ID = input("Lütfen müşteri numaranızı giriniz: ")
    credit_card=0
    credit_digits = 0
    credit_card = input("Lütfen kredi kartı numarasını giriniz: ")

    if(len(credit_card)==16):

        print("Doğru kredi kartı numarası girdiniz.")
        #credit_digits = input("Lütfen kredi kartı cvc kodunu giriniz: ")
    else :
       credit_card = input("Hatalı tuşlama girdiniz.Lütfen 16 haneli kredi kartı numaranızı giriniz.: ")
    credit_digits = input("Lütfen kredi kartı cvc kodunu giriniz: ")
    if (len(credit_digits) == 3):
         print("işlem başarılı")

    else:
        credit_digits = input("Hatalı tuşlama girdiniz.Lütfen 3 haneli cvc numaranızı giriniz.: ")

    print("Siparişiniz başarılı şekilde alınmıştır.Afiyet Olsun :)")
    time_of_order = datetime.datetime.now()

    with open('Siparis_Dosyası.csv', 'a') as orders:
        orders = csv.writer(orders, delimiter=',')

        orders.writerow([name, ID, credit_card, credit_digits, order.get_description(), time_of_order])


if __name__ == '__main__':
    main()

